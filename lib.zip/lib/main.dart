

  import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'models/producto.dart';
import 'productos_page.dart';

void main() {
  runApp(const InventarioApp());
}

class InventarioApp extends StatelessWidget {
  const InventarioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'InventarioApp',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.blue,
        ),
        useMaterial3: true,
      ),
      home: const RegistroProductoPage(),
    );
  }
}

class RegistroProductoPage extends StatefulWidget {
  const RegistroProductoPage({super.key});

  @override
  State<RegistroProductoPage> createState() {
    return _RegistroProductoPageState();
  }
}

class _RegistroProductoPageState
    extends State<RegistroProductoPage> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _codigoController =
      TextEditingController();

  final TextEditingController _nombreController =
      TextEditingController();

  final TextEditingController _precioController =
      TextEditingController();

  String? _categoria;

  double _stock = 0;

  String _estado = 'Disponible';

  DateTime? _fechaIngreso;

  bool _perecible = false;

  final List<Producto> _productos = <Producto>[];

  @override
  void dispose() {
    _codigoController.dispose();
    _nombreController.dispose();
    _precioController.dispose();
    super.dispose();
  }

  // Convierte la primera letra de cada palabra a mayúscula.
  String capitalizarPalabras(String texto) {
    return texto
        .trim()
        .split(' ')
        .where((palabra) => palabra.isNotEmpty)
        .map(
          (palabra) =>
              palabra[0].toUpperCase() +
              palabra.substring(1).toLowerCase(),
        )
        .join(' ');
  }

  // Permite seleccionar una fecha que no sea futura.
  Future<void> seleccionarFecha() async {
    final DateTime ahora = DateTime.now();

    final DateTime? fecha = await showDatePicker(
      context: context,
      initialDate: _fechaIngreso ?? ahora,
      firstDate: DateTime(2020),
      lastDate: ahora,
      helpText: 'Seleccione la fecha de ingreso',
    );

    if (fecha != null) {
      setState(() {
        _fechaIngreso = fecha;
      });
    }
  }

  void registrarProducto() {
    // Primero validamos los TextFormField.
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // Validamos la fecha por separado.
    if (_fechaIngreso == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Debe seleccionar la fecha de ingreso',
          ),
        ),
      );
      return;
    }

    final double precio =
        double.parse(_precioController.text.trim());

    final Producto producto = Producto(
      codigo: _codigoController.text.trim(),
      nombre: capitalizarPalabras(
        _nombreController.text,
      ),
      categoria: _categoria!,
      precio: precio,
      stock: _stock.toInt(),
      estado: _estado,
      fechaIngreso: _fechaIngreso!,
      perecible: _perecible,
    );

    // Guardamos el producto temporalmente en memoria.
    setState(() {
      _productos.add(producto);
    });

    // Limpiamos el formulario.
    _codigoController.clear();
    _nombreController.clear();
    _precioController.clear();

    setState(() {
      _categoria = null;
      _stock = 0;
      _estado = 'Disponible';
      _fechaIngreso = null;
      _perecible = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Producto registrado correctamente',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('InventarioApp'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Badge(
              label: Text(
                _productos.length.toString(),
              ),
              child: IconButton(
                icon: const Icon(
                  Icons.table_chart,
                ),
                tooltip: 'Ver productos',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) {
                        return ProductosPage(
                          productos: _productos,
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),

      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [

            // TÍTULO
            const Text(
              'Registro de productos',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            // CÓDIGO
            TextFormField(
              controller: _codigoController,
              keyboardType: TextInputType.number,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
                LengthLimitingTextInputFormatter(6),
              ],
              decoration: const InputDecoration(
                labelText: 'Código del producto',
                hintText: '6 dígitos',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.qr_code),
              ),
              validator: (value) {
                if (value == null ||
                    value.trim().isEmpty) {
                  return 'El código es obligatorio';
                }

                if (value.length != 6) {
                  return 'Debe tener exactamente 6 dígitos';
                }

                return null;
              },
            ),

            const SizedBox(height: 16),

            // NOMBRE
            TextFormField(
              controller: _nombreController,
              textCapitalization:
                  TextCapitalization.words,
              decoration: const InputDecoration(
                labelText: 'Nombre del producto',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.inventory_2),
              ),
              validator: (value) {
                if (value == null ||
                    value.trim().isEmpty) {
                  return 'El nombre es obligatorio';
                }

                if (value.trim().length < 2) {
                  return 'Ingrese un nombre válido';
                }

                return null;
              },
            ),

            const SizedBox(height: 16),

            // CATEGORÍA
            DropdownButtonFormField<String>(
              value: _categoria,
              decoration: const InputDecoration(
                labelText: 'Categoría',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.category),
              ),
              items: const [
                DropdownMenuItem(
                  value: 'Abarrotes',
                  child: Text('Abarrotes'),
                ),
                DropdownMenuItem(
                  value: 'Bebidas',
                  child: Text('Bebidas'),
                ),
                DropdownMenuItem(
                  value: 'Limpieza',
                  child: Text('Limpieza'),
                ),
                DropdownMenuItem(
                  value: 'Golosinas',
                  child: Text('Golosinas'),
                ),
                DropdownMenuItem(
                  value: 'Lácteos',
                  child: Text('Lácteos'),
                ),
                DropdownMenuItem(
                  value: 'Otro',
                  child: Text('Otro'),
                ),
              ],
              onChanged: (value) {
                setState(() {
                  _categoria = value;
                });
              },
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Seleccione una categoría';
                }

                return null;
              },
            ),

            const SizedBox(height: 16),

            // PRECIO
            TextFormField(
              controller: _precioController,
              keyboardType:
                  const TextInputType.numberWithOptions(
                decimal: true,
              ),
              decoration: const InputDecoration(
                labelText: 'Precio unitario (S/)',
                hintText: 'Ejemplo: 4.50',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.attach_money),
              ),
              validator: (value) {
                if (value == null ||
                    value.trim().isEmpty) {
                  return 'El precio es obligatorio';
                }

                final double? precio =
                    double.tryParse(value.trim());

                if (precio == null) {
                  return 'Ingrese un precio válido';
                }

                if (precio <= 0) {
                  return 'El precio debe ser mayor que 0';
                }

                return null;
              },
            ),

            const SizedBox(height: 20),

            // STOCK
            Text(
              'Cantidad en stock: ${_stock.toInt()}',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),

            Slider(
              value: _stock,
              min: 0,
              max: 80,
              divisions: 100,
              label: _stock.toInt().toString(),
              onChanged: (value) {
                setState(() {
                  _stock = value;
                });
              },
            ),

            const SizedBox(height: 16),

            // ESTADO
            const Text(
              'Estado del producto',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            SegmentedButton<String>(
              segments: const [
                ButtonSegment<String>(
                  value: 'Disponible',
                  label: Text('Disponible'),
                  icon: Icon(Icons.check_circle),
                ),
                ButtonSegment<String>(
                  value: 'Agotado',
                  label: Text('Agotado'),
                  icon: Icon(Icons.cancel),
                ),
              ],
              selected: <String>{_estado},
              onSelectionChanged:
                  (Set<String> seleccion) {
                setState(() {
                  _estado = seleccion.first;
                });
              },
            ),

            const SizedBox(height: 16),

            // FECHA
            Card(
              child: ListTile(
                leading: const Icon(
                  Icons.calendar_month,
                ),
                title: Text(
                  _fechaIngreso == null
                      ? 'Fecha de ingreso'
                      : 'Fecha: '
                          '${_fechaIngreso!.day}/'
                          '${_fechaIngreso!.month}/'
                          '${_fechaIngreso!.year}',
                ),
                subtitle: const Text(
                  'No puede ser una fecha futura',
                ),
                trailing: const Icon(
                  Icons.arrow_forward_ios,
                ),
                onTap: seleccionarFecha,
              ),
            ),

            const SizedBox(height: 8),

            // PERECIBLE
            SwitchListTile(
              title: const Text(
                '¿Producto perecible?',
              ),
              subtitle: Text(
                _perecible
                    ? 'Sí, es perecible'
                    : 'No, no es perecible',
              ),
              value: _perecible,
              onChanged: (value) {
                setState(() {
                  _perecible = value;
                });
              },
            ),

            const SizedBox(height: 20),

            // BOTÓN REGISTRAR
            SizedBox(
              height: 52,
              child: ElevatedButton.icon(
                onPressed: registrarProducto,
                icon: const Icon(Icons.save),
                label: const Text(
                  'Registrar producto',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ),

            const SizedBox(height: 12),

            // BOTÓN VER TABLA
            OutlinedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return ProductosPage(
                        productos: _productos,
                      );
                    },
                  ),
                );
              },
              icon: const Icon(Icons.table_chart),
              label: const Text(
                'Ver productos registrados',
              ),
            ),
          ],
        ),
      ),
    );
  }
}