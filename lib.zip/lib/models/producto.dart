class Producto {
  final String codigo;
  final String nombre;
  final String categoria;
  final double precio;
  final int stock;
  final String estado;
  final DateTime fechaIngreso;
  final bool perecible;

  const Producto({
    required this.codigo,
    required this.nombre,
    required this.categoria,
    required this.precio,
    required this.stock,
    required this.estado,
    required this.fechaIngreso,
    required this.perecible,
  });
}